/*
  healing.c - Allow negative radiation damage to repair ships.

  Jason Hood, 10 & 11 June, 2010.

  Requires and assumes v1.1.  Single-player usage requires Console (I cheated,
  letting it load Server, rather than having to patch for it).
*/

#define WIN32_LEAN_AND_MEAN
#include <windows.h>

#define NAKED	__declspec(naked)


PBYTE server;


// Allow negative damage values.
#define ADDR_NEGDMG1 ((PBYTE)(0x6337b30+2))	// from ini
#define ADDR_NEGDMG2 ((PBYTE)(0x633ad42+2))	// internal flag

// Add damage rather than subtract.
#define ADDR_ADDDMG1 (0x6cea5e4 - 0x6ce0000)	// equipment
#define ADDR_ADDDMG2 (0x6ceac35 - 0x6ce0000)	// collision group
#define ADDR_ADDDMG3 (0x6ceed1d - 0x6ce0000)	// hull

// Test for a negative damage.
#define ADDR_READDMG (server + 0x6d01197   - 0x6ce0000)
#define ADDR_APPLY	      (0x6d01258+1 - 0x6ce0000)


DWORD dummy;
#define ProtectX( addr, size ) \
  VirtualProtect( addr, size, PAGE_EXECUTE_READWRITE, &dummy );

#define RELOFS( from, to ) \
  (DWORD)(to) - (DWORD)(from) - 4;

#define CALL( from, to ) \
  *(PBYTE)(from) = 0xe8; \
  *(PDWORD)((DWORD)from+1) = RELOFS( (DWORD)from+1, to )


DWORD orig_call;
DWORD addr_equip, addr_group, addr_hull;



NAKED
void Equip_Hook( void )
{
  __asm {
	fadd	dword ptr [esp+0x10+4]
	mov	ebx, [ebp+0x0C] 	// CEquip::GetMaxHitPoints
	fcom	dword ptr [ebx+0x1C]
	fnstsw	ax
	test	ah, 0x41		// health <= max
	jnz	done			// yes
	fstp	st
	fld	dword ptr [ebx+0x1C]
  done:
	pop	eax
	pop	ebx
	jmp	eax
  }
}


NAKED
void Group_Hook( void )
{
  __asm {
	fsubr	dword ptr [esp+0x10+4]
	fadd	dword ptr [esp+0x10+4]
	mov	ecx, [ebp+0x04] 	// CArchGroup::GetMaxHitPoints
	fild	dword ptr [ecx+0x10]
	fcom	st(1)
	fnstsw	ax
	test	ah, 1			// max < health
	jz	done			// no
	fxch
  done:
	fstp	st
	ret
  }
}


NAKED
void Hull_Hook( void )
{
  __asm {
	fadd	dword ptr [esp+0x14+4]
	fadd	dword ptr [esp+0x14+4]
	mov	ecx, [esi+0x10]
	mov	ecx, [ecx+0x88] 	// CSimple::get_max_hit_pts
	fcom	dword ptr [ecx+0x1C]
	fnstsw	ax
	test	ah, 0x41
	jnz	done
	fstp	st
	fld	dword ptr [ecx+0x1C]
  done:
	ret
  }
}


BYTE repair;

NAKED
void Damage_Hook( void )
{
  __asm {
	fnstsw	ax
	test	ah, 1		// damage < 0
	setnz	repair
	jz	done
	fchs
  done:
	test	ah, 0x40	// damage == 0
	ret
  }
}


NAKED
void Apply_Hook()
{
  __asm {
	cmp	repair, 0
	jne	patch
	jmp	orig_call

  patch:
	push	edx
	push	eax

	mov	repair, 0
	mov	al, 0xe8
	mov	edx, server
	mov	[edx+ADDR_ADDDMG1], al
	mov	[edx+ADDR_ADDDMG2], al
	mov	[edx+ADDR_ADDDMG3], al
	mov	eax, addr_equip
	mov	[edx+ADDR_ADDDMG1+1], eax
	mov	eax, addr_group
	mov	[edx+ADDR_ADDDMG2+1], eax
	mov	eax, addr_hull
	mov	[edx+ADDR_ADDDMG3+1], eax

	call	orig_call

	mov	eax, server
	mov	dword ptr [eax+ADDR_ADDDMG1],	0x10246CD8
	mov	byte  ptr [eax+ADDR_ADDDMG1+4], 0x5B
	mov	cl,  0xF6
	mov	edx, 0x067541C4
	mov	[eax+ADDR_ADDDMG2],   cl
	mov	[eax+ADDR_ADDDMG2+1], edx
	mov	[eax+ADDR_ADDDMG3],   cl
	mov	[eax+ADDR_ADDDMG3+1], edx

	ret	8
  }
}


void Patch()
{
  server = (PBYTE)GetModuleHandle( "server.dll" );
  if (server == NULL)
    return;

  ProtectX( ADDR_NEGDMG1, 1 );
  ProtectX( ADDR_NEGDMG2, 1 );

  ProtectX( server + ADDR_ADDDMG1, 5 );
  //ProtectX( server + ADDR_ADDDMG2, 5 );
  ProtectX( server + ADDR_ADDDMG3, 5 );
  ProtectX( ADDR_READDMG, 5 );
  //ProtectX( server + ADDR_APPLY, 4 );

  // *ADDR_NEGDMG1 =			// uncomment to show radiation alert
  *ADDR_NEGDMG2 = 0x40; 		// <= 0 --> != 0

  addr_equip = RELOFS( server + ADDR_ADDDMG1+1, Equip_Hook );
  addr_group = RELOFS( server + ADDR_ADDDMG2+1, Group_Hook );
  addr_hull  = RELOFS( server + ADDR_ADDDMG3+1, Hull_Hook  );

  CALL( ADDR_READDMG, Damage_Hook );
  *(PDWORD)(server + ADDR_APPLY) = RELOFS( server + ADDR_APPLY, Apply_Hook );
  orig_call = (DWORD)server + ADDR_APPLY + 0x83 + 4;
}


BOOL WINAPI DllMain( HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpvReserved )
{
  if (fdwReason == DLL_PROCESS_ATTACH)
    Patch();

  return TRUE;
}
