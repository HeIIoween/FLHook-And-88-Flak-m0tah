				    Healing
				 by Jason Hood

				  Version 1.00


Healing is a Freelancer plugin that allows negative damage values, providing a
zone repair facility.  The radiation alert is not shown.

To install it, copy HEALING.DLL to Freelancer's EXE directory and add it to the
[Libraries] section of EXE\dacom.ini and EXE\dacomsrv.ini.  I've been lazy, so
single-player users will need Console (or Moors) before Healing, in order to
have server.dll loaded.

NOTE: it requires and assumes the official patch has been installed.


Jason Hood, 11 June, 2010.
http://freelancer.adoxa.cjb.net/
