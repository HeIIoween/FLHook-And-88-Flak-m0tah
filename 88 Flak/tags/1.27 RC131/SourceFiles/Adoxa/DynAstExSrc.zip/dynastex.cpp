/*
  dynastex.cpp - Dynamic Asteroid Extensions.

  Jason Hood, 13 July, 2010.

  Recognise hit_pts and mass for [DynamicAsteroid].

  Build (VC6):
	rc dynastex.rc
	cl /nologo /W3 /Ox /Gf /MD /LD dynastex.cpp dynastex.res

  Install:
    copy to EXE and add an entry to [Libraries] in EXE\dacom.ini.

  Requires and assumes v1.1 of common.dll.
*/

#define _WIN32_WINNT 0x0400
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <map>

#define NAKED	__declspec(naked)
#define STDCALL __stdcall


#define ADDR_HIT     ((PBYTE)0x5254d2)
#define ADDR_CREATE  ((PDWORD)(0x525eec+1))
#define ADDR_RESET   ((PBYTE)0x52610e)
#define ADDR_DESTROY ((PDWORD)0x5dce38)
#define ADDR_DEFAULT ((PBYTE)0x62fa1e4)

#define ADDR_MASS    ((PDWORD)(0x62a2b2e+1))


DWORD dummy;
#define ProtectX( addr, size ) \
  VirtualProtect( addr, size, PAGE_EXECUTE_READWRITE, &dummy );

#define RELOFS( from, to ) \
  *(PDWORD)((DWORD)(from)) = (DWORD)(to) - (DWORD)(from) - 4;

#define CALL( from, to ) \
  *(PBYTE)(from) = 0xE8; \
  RELOFS( (DWORD)(from)+1, to )

#define ABSOFS( from ) \
  ((DWORD)(from) + *((PDWORD)(from)) + 4)


// hit_pts

struct DynAstHP
{
  float hit_pts;
  float health;
};

typedef std::map<LPVOID, DynAstHP> MDynAst;
typedef MDynAst::iterator	   IDynAst;

MDynAst DynAst;

DWORD create, destroy;


void STDCALL Create( LPVOID dynast, float hit_pts )
{
  DynAstHP da;

  da.hit_pts = hit_pts; 	// health initialised on reset
  DynAst[dynast] = da;
}


void STDCALL Destroy( LPVOID dynast )
{
  DynAst.erase( dynast );
}


void STDCALL Reset( LPVOID dynast )
{
  IDynAst iter = DynAst.find( dynast );
  if (iter != DynAst.end())
  {
    float var = iter->second.hit_pts * 0.1f;	// 10% variance
    var = 2 * var * rand() / RAND_MAX - var;
    iter->second.health = iter->second.hit_pts + var;
  }
}


bool STDCALL Hit( LPVOID dynast, float dmg )
{
  IDynAst iter = DynAst.find( dynast );
  if (iter == DynAst.end())
    return false;

  iter->second.health -= dmg;
  return (iter->second.health > 0);
}


NAKED
void Create_Hook()
{
  __asm {
	call	create
	test	eax, eax
	jz	done
	push	eax

	mov	ecx, [eax+0x10]
	mov	ecx, [ecx+0x88] 	// archetype
	push	[ecx+0x1c]		// hit_pts
	push	eax
	call	Create

	pop	eax
  done:
	ret
  }
}


NAKED
void Destroy_Hook()
{
  _asm {
       push	ecx

       push	ecx
       call	Destroy

       pop	ecx
       jmp	destroy
  }
}


NAKED
void Reset_Hook()
{
  __asm {
	mov	edx, [esi+12]
	mov	eax, [edx+edi*4]
	push	eax

	push	eax
	call	Reset

	pop	eax
	ret
  }
}


NAKED
void Hit_Hook()
{
  __asm {
	and	edx, 7
	cmp	dl, 7
	jne	done

	mov	ecx, [ecx+0x10]
	mov	ecx, [ecx+0x88]
	push	[ecx+0x80]		// hull_damage of the hitting weapon
	push	edi
	call	Hit
	test	al, al
  done:
	ret
  }
}


// mass

float STDCALL adjust_mass( float mass )
{
  float var = mass * 0.1f;		// 10% variance
  var = 2 * var * rand() / RAND_MAX - var;
  return mass + var;
}


DWORD BuildIVP;

NAKED
void Mass_Hook()
{
  __asm {
	mov	eax, [esi+0x88]
	mov	eax, [eax+0x20] 	// mass
	push	eax
	call	adjust_mass
	fstp	dword ptr [esp+0x18+4]	// reset for CreateParms
	jmp	BuildIVP
  }
}


void Patch()
{
  ProtectX( ADDR_HIT,	  6 );
  //ProtectX( ADDR_CREATE,  4 );
  ProtectX( ADDR_RESET,   6 );
  ProtectX( ADDR_DESTROY, 4 );
  ProtectX( ADDR_DEFAULT, 7 );

  ProtectX( ADDR_MASS, 4 );

  create = ABSOFS( ADDR_CREATE );
  RELOFS( ADDR_CREATE, Create_Hook );

  destroy = *ADDR_DESTROY;
  *ADDR_DESTROY = (DWORD)Destroy_Hook;

  CALL( ADDR_HIT,   Hit_Hook );
  CALL( ADDR_RESET, Reset_Hook );
  ADDR_HIT[5] = ADDR_RESET[5] = 0x90;

  // mov [esi+13], 40	  ; [esi+10] set to 0, so this is enough for 2.0f
  // mov [esi+1c], ebp	  ; hit points initialised to 100, set to 0
  memcpy( ADDR_DEFAULT, "\xC6\x46\x13\x40\x89\x6E\x1C", 7 );

  BuildIVP = ABSOFS( ADDR_MASS );
  RELOFS( ADDR_MASS, Mass_Hook );
}


BOOL WINAPI DllMain( HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpvReserved )
{
  if (fdwReason == DLL_PROCESS_ATTACH)
    Patch();

  return TRUE;
}
