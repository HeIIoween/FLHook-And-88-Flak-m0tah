				    DynAstEx
				 by Jason Hood

				  Version 1.00


Dynamic Asteroid Extensions is a Freelancer plugin that recognizes the hit_pts
and mass values for [DynamicAsteroid] sections.  Furthermore, a 10% variance is
applied to each asteroid (e.g. if "hit_pts = 100" then it will range from 90 to
110; if "mass = 1" [the default] then it will range from 0.9 to 1.1).

To install it, copy DYNASTEX.DLL to Freelancer's EXE directory and add it to the
[Libraries] section of EXE\dacom.ini.

NOTE: it requires and assumes the official patch has been installed.


Jason Hood, 13 July, 2010.
http://freelancer.adoxa.cjb.net/
