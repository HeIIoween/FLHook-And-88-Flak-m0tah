/*
  chatlog.c - Log Freelancer's chat output to file.

  Jason Hood, 30 December, 2009.

  Intercepts a call directly before displaying the output.
  The chat is written to EXE\ingamechat.txt of the form:

	[YYYY-MM-DD HH:MM:SS] chat output


  v1.01, 31 May, 2010:
  + record new & departing player messages.

  v1.02, 16 June, 2010:
  * write file as UTF-8.


  Build (VC6):
	rc chatlog.rc
	cl /nologo /W3 /Ox /Gf /MD /LD chatlog.c chatlog.res

  Install:
	copy chatlog.dll to EXE and add it to [Libraries] in EXE\dacom.ini.
*/

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdio.h>

#define NAKED	__declspec(naked)
#define STDCALL __stdcall


#define RELOFS( from, to ) \
  *(PDWORD)(from) = (DWORD)(to) - (DWORD)(from) - 4;

#define CALL( from, to ) \
  *(PBYTE)(from) = 0xe8; \
  RELOFS( (DWORD)from+1, to )


#define LOGFILE "ingamechat.txt"

WCHAR chat[256];
UINT  len;


void write( void )
{
  SYSTEMTIME st;
  FILE* file;

  GetLocalTime( &st );
  file = fopen( "ingamechat.txt", "a" );
  if (file)
  {
    char chata[256*3];
    WideCharToMultiByte( CP_UTF8, 0, chat, -1, chata, 256*3, NULL, NULL );
    fprintf( file, "[%d-%02d-%02d %02d:%02d:%02d] %s\n",
		   st.wYear, st.wMonth, st.wDay,
		   st.wHour, st.wMinute, st.wSecond,
		   chata );
    fclose( file );
  }
}


void STDCALL player( LPCWSTR name, BOOL departing )
{
  swprintf( chat, L"%s player: %s", (departing) ? L"Departing" : L"New", name );
  write();
}


NAKED
void Chat_Hook( void )
{
  __asm {
	push	eax
	push	ecx
	push	[esp+12+8]
	push	edx
	push	offset len
	push	256
	push	offset chat
	call	dword ptr [eax+8] // BinaryRDLReader::extract_text_from_buffer
	call	write
	pop	ecx
	pop	eax
	jmp	dword ptr [eax]   // BinaryRDLReader::read_buffer
  }
}

DWORD chat_addr = (DWORD)Chat_Hook;


NAKED
void NewPlayer_Hook( void )
{
  __asm {
	push	0
	push	[esp+0x08+8]
	call	player

	mov	al, ds:[0x66d44c]
	ret
  }
}


NAKED
void DepartingPlayer_Hook( void )
{
  __asm {
	push	1
	push	[esp+0x5c+8]
	call	player

	mov	al, ds:[0x66d44c]
	ret
  }
}


BOOL WINAPI DllMain( HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpvReserved )
{
  if (fdwReason == DLL_PROCESS_ATTACH)
  {
    DWORD dummy;
    FILE* file;

    file = fopen( LOGFILE, "w" );
    if (file)
    {
      fputs( "\xef\xbb\xbf", file );
      fclose( file );
    }
    wcscpy( chat, L"Freelancer started." );
    write();

    VirtualProtect( (LPVOID)0x46a247, 4, PAGE_EXECUTE_READWRITE, &dummy );
    *(PDWORD*)0x46a247 = &chat_addr;
    CALL( 0x46aafe, NewPlayer_Hook );
    CALL( 0x46af24, DepartingPlayer_Hook );
  }
  else if (fdwReason == DLL_PROCESS_DETACH)
  {
    wcscpy( chat, L"Freelancer ended." );
    write();
  }

  return TRUE;
}
