				   HUD Shift
				 by Jason Hood

				  Version 2.00


HUD Shift is a plugin to reposition items in the HUD.  It can be installed
either in EXE\dacom.ini (add an entry to [Libraries]), or to EXE\freelancer.ini
(add an entry to [Initial SP DLLs]).  Either use the full path to hudshift.dll
for the entry, or copy it to EXE (former) or DLLS\BIN (latter).  The latter
will be loaded every time a game is loaded, allowing positions to be changed
on the fly; the former will only be loaded once.  Copy hudshift.ini to
DATA\INTERFACE and edit as required (remove the semicolon from the [;HUDShift]
section that does what you require, or add your own [HUDShift] section).


Jason Hood, 19 June, 2010.
http://freelancer.adoxa.cjb.net/
