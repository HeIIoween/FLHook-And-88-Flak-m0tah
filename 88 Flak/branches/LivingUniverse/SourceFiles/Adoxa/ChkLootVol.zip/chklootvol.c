/*
  chklootvol.cpp - Check the volume of loot, to prevent NPC inaction.

  Jason Hood, 20 September, 2010.

  Install:
    Copy CHKLOOTVOL.DLL to the EXE directory and add it to the [Libraries]
    section of EXE\dacom.ini (and probably dacomsrv.ini, too).
    Requires and assumes v1.1.
*/

#define WIN32_LEAN_AND_MEAN
#include <windows.h>

#define NAKED	__declspec(naked)
#define STDCALL __stdcall


#define ADDR_CARGO	((PDWORD)(0x62ce8e8+1))
#define ADDR_VOLUME	((PBYTE)0x62ce9d9)


DWORD dummy;
#define ProtectX( addr, size ) \
  VirtualProtect( addr, size, PAGE_EXECUTE_READWRITE, &dummy );

#define RELOFS( from, to ) \
  *(PDWORD)((DWORD)(from)) = (DWORD)(to) - (DWORD)(from) - 4;

#define CALL( from, to ) \
  *(PBYTE)(from) = 0xE8; \
  RELOFS( (DWORD)(from)+1, to )

#define NEWOFS( from, to, prev ) \
  prev = (DWORD)(from) + *((PDWORD)(from)) + 4; \
  RELOFS( from, to )


float cargo_hold_remaining;


DWORD Cargo_Org;

NAKED
void Cargo_Hook( void )
{
  __asm {
	call	Cargo_Org
	fst	cargo_hold_remaining
	ret
  }
}


NAKED
void Volume_Hook( void )
{
  __asm {
	fld	dword ptr [ecx+0x5c]	// volume of the loot
	fcomp	cargo_hold_remaining
	fnstsw	ax
	test	ah, 0x41
	jz	too_big
	mov	edx, [ecx]
	call	dword ptr [edx+0x10]
	ret

  too_big:
	mov	dword ptr [esp], 0x62ceaf4
	ret
  }
}


void Patch()
{
    ProtectX( ADDR_CARGO,  4 );
  //ProtectX( ADDR_VOLUME, 5 );

  NEWOFS( ADDR_CARGO, Cargo_Hook, Cargo_Org );
  CALL( ADDR_VOLUME, Volume_Hook );
}


BOOL WINAPI DllMain( HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpvReserved )
{
  if (fdwReason == DLL_PROCESS_ATTACH)
    Patch();

  return TRUE;
}
