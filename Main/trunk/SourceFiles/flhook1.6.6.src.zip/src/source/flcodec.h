#ifndef _FLCODEC_
#define _FLCODEC_

bool flc_decode(const char *ifile, const char *ofile);
bool flc_encode(const char *ifile, const char *ofile);

#endif