/*
Freelancer .FL Savegame encode/decoder

Credits to Sherlog <sherlog@t-online.de> for finding out the algorithm

� 2003 by Jor <flcodec@jors.net>

This is free software. Permission to copy, store and use granted as long
as this copyright note remains intact.

Compilation in a POSIX environment:

cc -O -o flcodec flcodec.c

Or in Wintendo 32 (get the free lcc compiler):

lcc -O flcodec.c
lcclnk -o flcodec.exe flcodec.obj

Changes on 11/11/09 by M0tah:
- Fixed to compile using VC
- Recreated flcodec.c used by the flcodec DLL by FiiK
- If the input file is not encoded, just copy to output file
- Closes file descriptor on failure

*/

#include <fcntl.h>
#include <errno.h>
#include <windows.h>
#include <io.h>

#include "flcodec.h"

/* On Windows we need to turn on transparent file IO - this is default on Unix. */
#ifndef _WIN32
#define O_BINARY 0
#endif

/* Very Secret Key - this is Microsoft Security In Action[tm] */
const char gene[] = "Gene";

int decode(const char *ifile, const char *ofile)
{
	int ifd, ofd, i, l, len, rc;
	char *mem, *buff, c, k, r;

	ifd = _open(ifile,O_RDONLY | O_BINARY);

	if (ifd == -1)
	{
		return FLCODECERR_FILEOPENFAILED;
	}

	len = _lseek(ifd, 0, SEEK_END);
	_lseek(ifd, 0, SEEK_SET);

	mem = malloc(len + 1);
	if (mem == NULL)
	{
		_close(ifd);
		return FLCODECERR_MEMORYALLOCFAILED;
	}

	rc = _read(ifd, mem, len);
	_close(ifd);
	if (rc != len)
	{
		return FLCODECERR_FILEREADFAILED;
	}

	/*if (strncmp(mem, "FLS1", 4) != 0) {
	return FLCODECERR_NOTFLS1FILE;
	}*/

	ofd = _open(ofile, O_CREAT | O_TRUNC | O_WRONLY | O_BINARY, 0640);
	if (ofd == -1)
	{
		return FLCODECERR_FILECREATEFAILED;
	}

	/* skip FLS1 */
	buff = mem + 4;
	l = len - 4;

	if (strncmp(mem, "FLS1", 4) != 0)
	{
		/* Just copy file (not encrypted) */
		rc = _write(ofd, mem, len);
		if (rc != len)
		{
			_close(ofd);
			return FLCODECERR_FILEWRITEFAILED;
		}
	}
	else
	{
		i = 0;
		while (i < l)
		{

			c = buff[i];
			k = (gene[i % 4] + i) % 256;

			r = c ^ (k | 0x80);

			rc = _write(ofd, &r, 1);
			if (rc != 1)
			{
				_close(ofd);
				return FLCODECERR_FILEWRITEFAILED;
			}

			i++;
		}
	}

	_close(ofd);
	return FLCODECERR_OK;
}

int encode(const char *ifile, const char *ofile)
{
	int ifd, ofd, i, l, len, rc;
	char *mem, *buff, c, k, r;

	ifd = _open(ifile,O_RDONLY | O_BINARY);

	if (ifd == -1)
	{
		return FLCODECERR_FILEOPENFAILED;
	}

	len = _lseek(ifd, 0, SEEK_END);
	_lseek(ifd, 0, SEEK_SET);

	mem = malloc(len + 1);
	if (mem == NULL)
	{
		_close(ifd);
		return FLCODECERR_MEMORYALLOCFAILED;
	}

	rc = _read(ifd, mem, len);
	_close(ifd);
	if (rc != len)
	{
		return FLCODECERR_FILEREADFAILED;
	}

	ofd = _open(ofile, O_CREAT | _O_EXCL | O_TRUNC | O_WRONLY | O_BINARY, 0640);
	if (ofd == -1)
	{
		if(errno == EEXIST)
		{
			int test;
			/* Read existing file and see if output should be encrypted */
			int ifdtest = _open(ifile,O_RDONLY | O_BINARY);
			if (ifdtest == -1)
				return FLCODECERR_FILEOPENFAILED;
			rc = _read(ifdtest, &test, 4);
			_close(ifdtest);
			if (rc != 4)
				return FLCODECERR_FILEREADFAILED;
			ofd = _open(ofile, O_CREAT | O_TRUNC | O_WRONLY | O_BINARY, 0640);
			if(ofd == -1)
			{
				return FLCODECERR_FILECREATEFAILED;
			}
			if(test != 0x464C5331) //"FLS1"
			{
				/* Just copy file */
				rc = _write(ofd, mem, len);
				_close(ofd);
				if(rc != len)
					return FLCODECERR_FILEWRITEFAILED;
				return FLCODECERR_OK;
			}
		}
		else
		{
			return FLCODECERR_FILECREATEFAILED;
		}
	}

	buff = mem;
	l = len;

	/* write magic token */
	rc = _write(ofd, "FLS1", 4);
	if (rc != 4)
	{
		_close(ofd);
		return FLCODECERR_FILEWRITEFAILED;
	}

	i = 0;
	while (i < l)
	{

		c = buff[i];
		k = (gene[i % 4] + i) % 256;

		r = c ^ (k | 0x80);

		rc = _write(ofd, &r, 1);
		if (rc != 1)
		{
			_close(ofd);
			return FLCODECERR_FILEWRITEFAILED;
		}

		i++;
	}
	_close(ofd);
	return FLCODECERR_OK;
}

int _stdcall flcodec(int nType, char* szSource, char* szDest)
{
	char szShortSource[MAX_PATH];
	if(!szSource || !szDest)
		return FLCODECERR_INVALIDARGUMENT;
	if(!GetShortPathNameA(szSource, szShortSource, MAX_PATH))
		return FLCODECERR_INVALIDFILENAME;
	switch(nType)
	{
	case FLCODEC_DECODE:
		return decode(szSource, szDest);
	case FLCODEC_ENCODE:
		return encode(szSource, szDest);
	default:
		return FLCODECERR_INVALIDARGUMENT;
	}
}
