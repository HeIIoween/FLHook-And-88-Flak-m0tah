#ifndef FLCODEC_H
#define FLCODEC_H

#define FLCODEC_DECODE              0x01
#define FLCODEC_ENCODE              0x02

#define FLCODECERR_FILEOPENFAILED      0x0100
#define FLCODECERR_MEMORYALLOCFAILED   0x0101
#define FLCODECERR_FILEREADFAILED      0x0102
#define FLCODECERR_FILECREATEFAILED    0x0103
#define FLCODECERR_FILEWRITEFAILED     0x0104
#define FLCODECERR_INVALIDARGUMENT     0x0105
#define FLCODECERR_INVALIDFILENAME     0x0106
#define FLCODECERR_NOTFLS1FILE         0x0107

#define FLCODECERR_OK                  0

/*
flcodec
-- decodes/encodes FL files

  int flcoded(int nType, const char * szSource, const char * szDest)

  Required headers:   flcodec.h
  Required Libraries: flcodec.lib
  Linked files:   flcodec.dll

  Return Value: 0 (also known as FLCODECERR_OK) if successful, nonzero otherwise (use FLCODECERR_ constants for error-handling)

  Parameters:
    nType           -   can be either FLCODEC_DECODE or FLCODEC_ENCODE
    szSource        -   source filename (can be long filename .. it will convert it to short)
    szDest          -   destination filename (may want to stick to short filepaths .. do this in your own code)

  Remarks:
    flcodec encodes and decodes .FL files.  The underlying code was written by:

        Sherlog <sherlog@t-online.de> for finding out the algorithm
                        and
                Jor <flcodec@jors.net>
    whereas I simply converted it to comply with Win32-DLL format.

  Usage:
    flcodec(FLCODEC_DECODE, "C:\\myflfile.fl", "C:\\myoutfile.txt"); // convert .fl file to text file
    flcodec(FLCODEC_ENCODE, "C:\\myoutfile.txt", "C:\\myflfile.fl"); // convert text file to .fl file
    
    You must pass ALL valid parameters to avoid failure within the DLL.

  Example:

  #include "flcodec.h"

  ...
        // Decode .fl file
        int nReturn;
        nReturn = flcodec(FLCODEC_DECODE, "C:\\Documents and Settings\\Administrator.GRIDSBU\\My Documents\\My Games\\Freelancer\\Accts\\MultiPlayer\\23-3515e41f\\04-13bc1c33.fl", "c:\\test.txt");
        if (nReturn != FLCODECERR_OK)
        {
            // Handle errors here
        }
  ...

*/
extern int _stdcall flcodec(int nType, char* szSource, char* szDest);

#endif  // FLCODEC_H