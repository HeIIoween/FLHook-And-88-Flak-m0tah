flcodec DLL for use with your own apps.
by FiiK/M0tah
freelancer@fiik.net

Details on the DLL are located in the src\flcodec.h header file.

Source of the DLL, recoded by M0tah, is in src\flcodec.c.
The only change from FiiK's version is handling of non-encrypted char files by copying the file to the destination.

VB users, use this declaration:
Public Declare Function flcodec Lib "flcodec.dll" (ByVal nType As Long, ByVal szSource As String, ByVal szDest As String) As Long
Then put flcodec.dll in either the program's directory or windows\system32.

Credits for encode/decode functionality:
Sherlog <sherlog@t-online.de> for finding out the algorithm
Jor <flcodec@jors.net> for making the c file source