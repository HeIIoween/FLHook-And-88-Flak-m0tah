Written by Jason Hood (Adoxa), 26 September, 2009.

Patch common.dll to allow pressing two keys to strafe diagonally.
This version only works with 1.1.

Build (VC 6):
	cl /nologo /W3 /GfX /Ox /MD /LD 8waystrafe.c

See http://the-starport.net/freelancer/forum/viewtopic.php?topic_id=2238 for more information.