/*
  8waystrafe.c - Allows diagonal strafe movement.

  Jason Hood, 26 September, 2009.

  Patch common.dll to allow pressing two keys to strafe diagonally.
  This version only works with 1.1.

  Build (VC 6):
	cl /nologo /W3 /GfX /Ox /MD /LD 8waystrafe.c
*/


#define WIN32_LEAN_AND_MEAN
#include <windows.h>


__declspec(naked)
void SetStrafe( void )
{
  __asm mov	edx, [ecx+0x18]
  __asm test	eax, eax
  __asm jz	ok
  __asm dec	edx
  __asm jz	left
  __asm dec	edx
  __asm jz	right
  __asm dec	edx
  __asm jz	up
  __asm dec	edx
  __asm jnz	ok
  //down:
  __asm cmp	eax, 3
  __asm jae	ok
  __asm lea	eax, [eax+eax+4]
  __asm jmp	ok
  up:
  __asm cmp	eax, 3
  __asm jae	ok
  __asm lea	eax, [eax+eax+3]
  __asm jmp	ok
  right:
  __asm cmp	eax, 2
  __asm jbe	ok
  __asm add	eax, 4
  __asm jmp	ok
  left:
  __asm cmp	eax, 2
  __asm jbe	ok
  __asm add	eax, 2
  ok:
  __asm mov	[ecx+0x18], eax
  __asm ret
}


__declspec(naked)
void controller( void )
{
  __asm mov	ecx, [esp+4+0x14]
  __asm mov	edx, [esp+4+0x18]
  __asm mov	eax, [esp+4+0x1C]
  __asm mov	[esp+4+0x08], ecx
  __asm mov	ecx, [esi+0x14]
  __asm mov	[esp+4+0x10], eax
  __asm mov	eax, [edi]
  __asm mov	[esp+4+0x0C], edx
  __asm mov	edx, [ecx+0x88]
  __asm fld	dword ptr [edx+0x0124]
  __asm push	eax
  __asm fld	dword ptr [esp+4+0x0C]
  __asm lea	ecx, [esp+4+0x0C]
  __asm fmul	st(0), st(1)
  __asm push	ecx
  __asm mov	ecx, esi
  __asm fstp	dword ptr [esp+4+0x10]
  __asm fld	dword ptr [esp+4+0x14]
  __asm fmul	st(0), st(1)
  __asm fstp	dword ptr [esp+4+0x14]
  __asm fld	dword ptr [esp+4+0x18]
  __asm fmul	st(0), st(1)
  __asm fstp	dword ptr [esp+4+0x18]
  __asm fstp	st(0)
  __asm mov	eax, 0x6285d60 //Common.?push@Controller@PhySys@@QAEXABVVector@@M@Z
  __asm call	eax
  __asm ret
}


__declspec(naked)
void left( void )
{
  __asm mov	eax, [esi+0x14]
  __asm fld	dword ptr [eax+0x08]
  __asm add	eax, 0x08
  __asm fld	dword ptr [eax+0x0C]
  __asm sub	esp, 0x0C
  __asm fld	dword ptr [eax+0x18]
  __asm lea	ecx, [esp+4+0x20]
  __asm fchs
  __asm fstp	dword ptr [esp+0x08]
  __asm fchs
  __asm fstp	dword ptr [esp+0x04]
  __asm fchs
  __asm fstp	dword ptr [esp]
  __asm mov	eax, 0x628B030
  __asm call	eax
  __asm ret
}


__declspec(naked)
void right( void )
{
  __asm mov	eax, [esi+0x14]
  __asm fld	dword ptr [eax+0x08]
  __asm add	eax, 0x08
  __asm fstp	dword ptr [esp+4+0x14]
  __asm fld	dword ptr [eax+0x0C]
  __asm fstp	dword ptr [esp+4+0x18]
  __asm fld	dword ptr [eax+0x18]
  __asm fstp	dword ptr [esp+4+0x1C]
  __asm ret
}


__declspec(naked)
void left_up( void )
{
  __asm call	left
  __asm call	controller
  __asm push	0x62bba01
  __asm ret
}


__declspec(naked)
void left_down( void )
{
  __asm call	left
  __asm call	controller
  __asm push	0x62bba1a
  __asm ret
}


__declspec(naked)
void right_up( void )
{
  __asm call	right
  __asm call	controller
  __asm push	0x62bba01
  __asm ret
}


__declspec(naked)
void right_down( void )
{
  __asm call	right
  __asm call	controller
  __asm push	0x62bba1a
  __asm ret
}


DWORD strafe_table[] =
{
  0x062BB9BA,		// left
  0x062BB9E8,		// right
  0x062BBA01,		// up
  0x062BBA1A,		// down
  (DWORD)left_up,
  (DWORD)left_down,
  (DWORD)right_up,
  (DWORD)right_down
};


void Patch( void )
{
  #define ADDR_STRAFE ((PBYTE)0x62bb949)
  #define ADDR_CNTRLR ((PBYTE)0x62bb9a8)

  DWORD dummy;

  if (*ADDR_STRAFE != 0x85)
    return;

  VirtualProtect( ADDR_STRAFE, 0x75, PAGE_EXECUTE_READWRITE, &dummy );
  ADDR_STRAFE[0] = 0xe8;
  *(DWORD*)(ADDR_STRAFE+1) = (PBYTE)SetStrafe - ADDR_STRAFE - 5;

  ADDR_CNTRLR[2] = 7;
  *(DWORD*)(ADDR_CNTRLR+14) = (DWORD)strafe_table;
}


BOOL WINAPI DllMain( HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpvReserved )
{
  if (fdwReason == DLL_PROCESS_ATTACH)
    Patch();

  return TRUE;
}
