#ifndef _COMMON_
#define _COMMON_

namespace Universe
{
	IMPORT uint get_base_id(char const *);
}

#endif
